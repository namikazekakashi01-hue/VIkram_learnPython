year = int(input(" Enter Year: "))

if year % 4 == 0 and year % 100 != 0:
    print("leap")
elif year % 100 == 0:
    if year % 400 == 0:
        print('leap')
    else:
        print('not leap year')
else: 
    print('not leap')

if year % 100 == 0:
    if year % 400 == 0:
        print('leap')
    else:
        print('not leap year')
elif year % 4 == 0:
    print("leap year")
else:
    print("not a leap year")