mon = int(input("month number is: "))

if mon == 0:
    print("january")
elif mon == 1:
    print("februrary")
elif mon == 2:
    print("march")
elif mon == 3:
    print("april")
elif mon == 4:
    print("may")
elif mon == 5:
    print("june")
elif mon == 6:
    print("july")
elif mon == 7:
    print("august")
elif mon == 8:
    print("september")
elif mon == 9:
    print("october")
elif mon == 10:
    print("november")
elif mon == 11:
    print("december")
else:
    print("invalid month number")