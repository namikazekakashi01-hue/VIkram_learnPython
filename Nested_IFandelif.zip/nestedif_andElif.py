temp = float(input('temp is: '))

if temp == 25:
    print('normal')
elif temp < 25:
    print('cold')
else:
    print('hot')