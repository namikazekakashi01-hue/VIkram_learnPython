Value = int(input("Give a value of numbers "))
if Value < 3:
    print(Value*Value)
elif Value > 3:
    print("Value is greater than 3")
else:
    print("Value is equal to 3")