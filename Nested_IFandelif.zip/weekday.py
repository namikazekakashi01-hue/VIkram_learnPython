dayNo = int(input("day number: "))

if dayNo == 0:
    print("Monday")
elif dayNo == 1:
    print("Tuesday")
elif dayNo == 2:
    print("Wednesday")
elif dayNo == 3:
    print("Thursday")
elif dayNo == 4:
    print("Friday")
elif dayNo == 5:
    print("Saturday")
elif dayNo == 6:
    print("Sunday")
else:
    print("invalid day")
