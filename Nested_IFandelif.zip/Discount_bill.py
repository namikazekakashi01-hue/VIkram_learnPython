bill = float(input('bill amount: '))

if bill < 1000:
    print("Your discount is 10 percent and your bill amount is", bill - (bill *0.1))
elif bill >= 1000 and bill <= 5000:
    print("Your discount is 15 percent and your bill amount is", bill - (bill * 0.15))
elif bill >= 5000 and bill <= 10000:
    print("Your discount is 20 percent and your bill amount is", bill - (bill * 0.20))
else:
    print("Your discount is 25 percent and your bill amount is", bill - (bill * 0.25))