st = 'python'

for x in st:
    print(x)