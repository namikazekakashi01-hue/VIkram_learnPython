num = 7

for i in range(num):
    if i == 5:
        break
else:
    print("ain't breaking today man" )

print("looks like you aint saying ur breaking shit today")