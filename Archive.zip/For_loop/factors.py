num = int(input("Enter a number: "))
factor = 0

for i in range(1, num + 1):
    if num % i == 0:
        factor = i
        print(factor)
    else:
        continue