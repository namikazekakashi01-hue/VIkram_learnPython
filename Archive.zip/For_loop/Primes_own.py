num = int(input("Enter a number: "))
x= 0
#the logic here is that prime number has only 2 factors so sum of the factors is (1 + itself)
#so here we find the sum of all the factors of a given number and if it is equal to (1 + num) then it is a prime number

for i in range(1, num+1):
    if num % i == 0:
        factor = i
        x += factor
    else:
        continue

if x == (1 + num):
    print("prime")
else:
    print("not prime")
    