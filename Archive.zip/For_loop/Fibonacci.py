num = int(input("Enter a number: "))
a = 0
b = 1
fib = 0

for i in range(1, num):
    fib = a + b
    a = b
    b = fib
print(fib)

