num = int(input("Enter a number: "))
fac = 1

for i in range(1,num + 1):
    fac *= i

print("factorial of given", num, "is", fac)