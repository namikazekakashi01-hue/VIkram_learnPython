num = int(input("Enter a number: "))
count= 0
#the logic here is that a prime number has only two factors(one and itself)
# So we count the  number of factors using variable count. 
# if count is 2 that means it has only two factors making it a prime number

for i in range(1, num+1):
    if num % i == 0:
        count += 1
    else:
        continue

if count == 2:
    print("prime")
else:
    print("not prime")