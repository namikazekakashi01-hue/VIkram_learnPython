num = int(input("Enter a number: "))
rev = 0
x = num

while num > 0:
    r = num % 10
    rev = rev*10 + r
    num //= 10

print(rev)
if rev == x:
    print("palindrome")
else:
    print("not a palindrome")