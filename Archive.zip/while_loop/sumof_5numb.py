num = int(input("how many numbers for the summation\n"))
print("give the values for", num, "digits")
i = 0
n= 0
sum = 0 
# i is the count of num inputs (0,1,2,3,4,...num)
# n is the input for the digits of numbers for the summation

while i < num:
    i = i+1
    n = int(input(""))
    sum = sum+n
print("sum is ", sum)