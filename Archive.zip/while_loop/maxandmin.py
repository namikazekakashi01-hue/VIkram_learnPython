num = int(input("max of how many values\n"))
print("give the values for", num, "digits")
max = float('-inf')
min = float('+inf')
i = 0

while i < num:
    i += 1
    val = int(input(''))
    if  val > max:
        max = val
    if val < min:
        min = val
print("max is",max)
print("min is",min)