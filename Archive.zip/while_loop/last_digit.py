n = 23521

while n>0:
    r = n % 10
    print(r)
    n = n // 10