n = int(input("Enter a number: "))
i = 0
sum = 0

while i < n:
    i = i + 1
    sum += i
print(sum)