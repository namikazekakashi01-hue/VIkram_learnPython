## Method - 1
for i in range(1,6):
    for j in range(1,6):
        if j <= i:
            print('*', end=' ')
    print('')


## Method - 2
for i in range(1,6):
    for j in range(1, i +1):
        print('*', end=' ')
    print('')

##Method - 3
for i in range(1,6):
    print( i * '*')

#Method - 4
i = 0
while i < 5:
    i += 1
    print('*' * i)