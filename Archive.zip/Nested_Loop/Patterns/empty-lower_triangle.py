# Method - 1
for i in range(1,6):
    for j in range(1,6):
        if i >j:
            print(' ', end=' ')
        else:
            print('*', end=' ')
    print('')


# Method - 2
for x in range(1,6):
    print('  ' * (x -1), end='  ')
    print('* ' * (5 - (x -1)))